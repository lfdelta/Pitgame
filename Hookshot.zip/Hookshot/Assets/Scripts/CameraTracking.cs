﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraTracking : MonoBehaviour
{
	public Transform topTrigger;
	public Transform bottomTrigger;

	private Transform player;
	private bool playerGrounded;

	void Start () {
		// find and store the player transform	
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}

// snap to platforms
// 